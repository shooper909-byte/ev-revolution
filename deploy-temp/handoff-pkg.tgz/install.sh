#!/bin/bash
# Installs the brand-site build into the eves-sisters-2.9.0 theme. Run from the unpacked package directory.
set -euo pipefail
PKG=$(pwd)
ROOT=/srv/htdocs
T=$ROOT/wp-content/themes/eves-sisters-2.9.0
MU=$ROOT/wp-content/mu-plugins
B=$ROOT/.es-backups-k4r8w2
TS=$(date -u +%Y%m%d-%H%M%S)
grep -q 'Version: 2.14.0' $T/style.css
php -l $PKG/es-lockdown.php
mkdir -p $B
tar -czf $B/theme-before-handoff-$TS.tgz -C $ROOT/wp-content/themes eves-sisters-2.9.0
cp $MU/es-lockdown.php $B/es-lockdown-before-handoff-$TS.php
cp -a $PKG/assets/next/static/. $T/assets/next/static/
mkdir -p $B/retired-pages-$TS
for f in care.html care-*.html treatments.html eves-secret.html peptide-care.html mrs-collection.html mrs-jones.html mrs-golden.html mrs-robinson.html; do
  [ -f $T/static-pages/$f ] && mv $T/static-pages/$f $B/retired-pages-$TS/
done
cp $PKG/static-pages/*.html $T/static-pages/
cp $PKG/es-lockdown.php $MU/es-lockdown.php
sed -i 's/Version: 2.14.0/Version: 2.15.0/' $T/style.css
wp cache flush
echo "INSTALLED ts=$TS pages=$(ls $T/static-pages | tr '\n' ' ') lockdown=$(sha256sum $MU/es-lockdown.php | cut -c1-12)"
