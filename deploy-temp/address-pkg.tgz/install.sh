#!/bin/bash
# Installs updated brand-site pages into the active eves-sisters theme. Run from the unpacked package directory.
set -euo pipefail
exec > /srv/htdocs/.es-ops-address/install.log 2>&1
PKG=$(pwd)
ROOT=/srv/htdocs
T=$(wp eval "echo get_template_directory();")
case "$T" in $ROOT/wp-content/themes/eves-sisters-*) ;; *) echo "unexpected theme $T"; exit 1;; esac
TN=$(basename $T)
B=$ROOT/.es-backups-k4r8w2
TS=$(date -u +%Y%m%d-%H%M%S)
grep -q 'Version: 2.15.0' $T/style.css || { echo 'unexpected theme version'; exit 1; }
tar -czf $B/static-before-address-$TS.tgz -C $T static-pages style.css
cp -a $PKG/assets/next/static/. $T/assets/next/static/
cp $PKG/static-pages/*.html $T/static-pages/
sed -i 's/Version: 2.15.0/Version: 2.15.1/' $T/style.css
wp cache flush
echo "INSTALLED ts=$TS theme=$TN"
