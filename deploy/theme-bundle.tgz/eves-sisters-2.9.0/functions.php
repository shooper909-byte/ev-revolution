<?php
if (!defined('ABSPATH')) { exit; }

function eves_sisters_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('woocommerce');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    register_nav_menus(array('primary' => __('Primary Menu', 'eves-sisters')));
}
add_action('after_setup_theme', 'eves_sisters_setup');

function eves_sisters_assets() {
    wp_enqueue_style('eves-sisters-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500&family=Playfair+Display:ital,wght@0,400;1,400&display=swap', array(), null);
    wp_enqueue_style('eves-sisters-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    wp_enqueue_script('eves-sisters-script', get_template_directory_uri() . '/assets/js/theme.js', array(), wp_get_theme()->get('Version'), true);
}
add_action('wp_enqueue_scripts', 'eves_sisters_assets');

function eves_sisters_body_classes($classes) {
    $classes[] = 'eves-sisters-theme';
    return $classes;
}
add_filter('body_class', 'eves_sisters_body_classes');

/* Serve editorial routes that do not yet have WordPress page records.
 * Existing pages and all WooCommerce endpoints continue through WordPress. */
function eves_sisters_virtual_pages() {
    if (is_admin()) { return; }
    $path = trim((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $templates = array(
        'contact' => 'page-contact.php',
        'disclaimer' => 'page-disclaimer.php',
    );
    if (isset($templates[$path])) {
        status_header(200);
        nocache_headers();
        include get_template_directory() . '/' . $templates[$path];
        exit;
    }
}
add_action('template_redirect', 'eves_sisters_virtual_pages', 0);

function eves_sisters_virtual_title($title) {
    if (is_admin()) { return $title; }
    $path = trim((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $titles = array('contact' => 'Contact', 'disclaimer' => 'Medical Disclaimer');
    return isset($titles[$path]) ? $titles[$path] . ' – Eve’s Sisters' : $title;
}
add_filter('pre_get_document_title', 'eves_sisters_virtual_title');

/* Serve the exported application assets at their original public URLs. Keeping
 * these URLs intact means the server HTML and hydrated React tree stay equal. */
function eves_sisters_export_asset() {
    if (is_admin()) { return; }

    $path = rawurldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    $theme = get_template_directory();
    $file = '';

    if ($path === '/next-asset' || $path === '/next-asset-v271' || $path === '/next-asset-v280' || $path === '/next-asset-v281' || $path === '/next-asset-v282' || $path === '/next-asset-v290' || $path === '/next-asset-v2100' || $path === '/next-asset-v2110' || $path === '/next-asset-v2111' || $path === '/next-asset-v2112' || $path === '/next-asset-v2113' || $path === '/next-asset-v2114' || $path === '/next-asset-v2115' || $path === '/next-asset-v2116' || $path === '/next-asset-v2117' || $path === '/next-asset-v2118' || $path === '/next-asset-v2119' || $path === '/next-asset-v21110' || $path === '/next-asset-v21111' || $path === '/next-asset-v21112' || $path === '/next-asset-v21113' || $path === '/next-asset-v21114' || $path === '/next-asset-v2120' || $path === '/next-asset-v2130') {
        $asset = isset($_GET['file']) ? rawurldecode((string) $_GET['file']) : '';
        if (strpos($asset, 'static/') === 0) {
            $file = $theme . '/assets/next/' . $asset;
        }
    } elseif (strpos($path, '/_next/static/') === 0) {
        $file = $theme . '/assets/next/static/' . substr($path, strlen('/_next/static/'));
    } elseif ($path === '/_next/image') {
        $source = isset($_GET['url']) ? rawurldecode((string) $_GET['url']) : '';
        if (strpos($source, '/images/') === 0) {
            $file = $theme . '/assets' . $source;
        }
    } elseif (strpos($path, '/images/') === 0) {
        $file = $theme . '/assets' . $path;
    } elseif ($path === '/opengraph-image.png' || $path === '/og-image') {
        $file = $theme . '/assets/images/opengraph-image.png';
    } elseif ($path === '/site-icon') {
        $file = $theme . '/assets/images/site-icon.svg';
    }

    if ($file === '') { return; }
    $assets_root = realpath($theme . '/assets');
    $resolved = realpath($file);
    if ($assets_root === false || $resolved === false || strpos($resolved, $assets_root . DIRECTORY_SEPARATOR) !== 0 || !is_readable($resolved)) {
        status_header(404);
        exit;
    }

    status_header(200);
    $type = wp_check_filetype($resolved);
    header('Content-Type: ' . ($type['type'] ? $type['type'] : 'application/octet-stream'));
    header('Cache-Control: public, max-age=31536000, immutable');
    $contents = file_get_contents($resolved);
    if (substr($resolved, -4) === '.css') {
        $contents = str_replace('url(/_next/static/', 'url(/next-asset-v2130?file=static/', $contents);
    }
    if (strpos(basename($resolved), 'webpack-') === 0) {
        $contents = str_replace(
            'r.p="/_next/"',
            'r.p="/next-asset-v2130?file="',
            $contents
        );
    }
    header('Content-Length: ' . strlen($contents));
    echo $contents;
    exit;
}
add_action('template_redirect', 'eves_sisters_export_asset', -2000);

/* Keep the exported newsletter form functional on WordPress. WordPress sends
 * the validated signup to the public Vercel production API, where Brevo
 * credentials stay server-side. EV_NEWSLETTER_WEBHOOK_URL may override the
 * production endpoint from wp-config.php or the server environment. */
function eves_sisters_newsletter_endpoint() {
    if (is_admin()) { return; }
    $path = (string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if ($path !== '/api/subscribe') { return; }

    header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
    if (strtoupper((string) $_SERVER['REQUEST_METHOD']) !== 'POST') {
        status_header(405);
        header('Allow: POST');
        echo wp_json_encode(array('message' => 'Method not allowed.'));
        exit;
    }

    $body = json_decode((string) file_get_contents('php://input'), true);
    $email = isset($body['email']) ? sanitize_email($body['email']) : '';
    if ($email === '' || !is_email($email)) {
        status_header(400);
        echo wp_json_encode(array('message' => 'Please enter a valid email address.'));
        exit;
    }

    $webhook = defined('EV_NEWSLETTER_WEBHOOK_URL') ? EV_NEWSLETTER_WEBHOOK_URL : getenv('EV_NEWSLETTER_WEBHOOK_URL');
    if (!$webhook) {
        $webhook = 'https://ev-revolution.vercel.app/api/subscribe';
    }

    $source = isset($body['source']) && in_array($body['source'], array('footer', 'popup', 'site'), true)
        ? $body['source']
        : 'site';
    $first_name = isset($body['firstName']) ? sanitize_text_field($body['firstName']) : '';

    $response = wp_remote_post($webhook, array(
        'timeout' => 12,
        'headers' => array('Content-Type' => 'application/json'),
        'body' => wp_json_encode(array(
            'email' => $email,
            'firstName' => $first_name,
            'source' => $source,
            'submittedAt' => gmdate('c'),
        )),
    ));
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) < 200 || wp_remote_retrieve_response_code($response) >= 300) {
        status_header(502);
        echo wp_json_encode(array('message' => 'Newsletter signup is temporarily unavailable.'));
        exit;
    }

    status_header(200);
    echo wp_json_encode(array('message' => "You're on the list."));
    exit;
}
add_action('template_redirect', 'eves_sisters_newsletter_endpoint', -1900);

/* Handoff for the exported care and Mrs. Collection contact forms. Only the
 * rendered contact fields are forwarded; clinical details stay out of WordPress. */
function eves_sisters_care_lead_endpoint() {
    if (is_admin()) { return; }
    $path = (string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if ($path !== '/api/care-lead') { return; }

    header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
    if (strtoupper((string) $_SERVER['REQUEST_METHOD']) !== 'POST') {
        status_header(405);
        header('Allow: POST');
        echo wp_json_encode(array('message' => 'Method not allowed.'));
        exit;
    }

    $body = json_decode((string) file_get_contents('php://input'), true);
    $program = isset($body['program']) ? sanitize_key($body['program']) : '';
    $programs = array(
        'weight-management' => array(
            'label' => 'Weight management',
            'source' => '/care/weight-management',
            'interests' => array('Oral Weight Care', 'GLP-1 Care', 'Complete Weight Care', 'I am not sure'),
            'plans' => array(),
        ),
        'hormones-menopause' => array(
            'label' => 'Hormones and menopause',
            'source' => '/care/hormones-menopause',
            'interests' => array('Perimenopause symptoms', 'Menopause symptoms', 'Vaginal or urinary symptoms', 'Sexual wellness', 'I am not sure'),
            'plans' => array(),
        ),
        'skin-beauty' => array(
            'label' => 'Skin and beauty',
            'source' => '/care/skin-beauty',
            'interests' => array('Acne', 'Hyperpigmentation', 'Fine lines or photoaging', 'Hormonal acne', 'Hair thinning or hair loss', 'Eyelash concerns', 'Multiple concerns', 'I am not sure'),
            'plans' => array('Skin Essentials', 'Skin and Hair Plus', 'Complete Skin and Beauty', 'Help me choose'),
        ),
        'mrs-jones' => array('label' => 'Mrs. Jones collection', 'source' => '/packages/mrs-jones', 'interests' => array('Weight Management', 'Menopause & Hormones', 'Skin & Beauty', 'Eve’s Secret', 'Not sure'), 'plans' => array()),
        'mrs-golden' => array('label' => 'Mrs. Golden collection', 'source' => '/packages/mrs-golden', 'interests' => array('Weight Management', 'Menopause & Hormones', 'Skin & Beauty', 'Eve’s Secret', 'Not sure'), 'plans' => array()),
        'mrs-robinson' => array('label' => 'Mrs. Robinson collection', 'source' => '/packages/mrs-robinson', 'interests' => array('Weight Management', 'Menopause & Hormones', 'Skin & Beauty', 'Eve’s Secret', 'Not sure'), 'plans' => array()),
    );
    if (!isset($programs[$program])) {
        status_header(400);
        echo wp_json_encode(array('message' => 'Invalid request.'));
        exit;
    }
    $config = $programs[$program];
    $first = isset($body['firstName']) ? sanitize_text_field($body['firstName']) : '';
    $last = isset($body['lastName']) ? sanitize_text_field($body['lastName']) : '';
    $email = isset($body['email']) ? sanitize_email($body['email']) : '';
    $mobile = isset($body['mobile']) ? sanitize_text_field($body['mobile']) : '';
    $state = isset($body['state']) ? strtoupper(sanitize_text_field($body['state'])) : '';
    $interest = isset($body['interest']) ? sanitize_text_field($body['interest']) : '';
    $plan = isset($body['plan']) ? sanitize_text_field($body['plan']) : '';
    $consent = isset($body['consent']) && $body['consent'] === true;

    $plan_invalid = count($config['plans']) > 0 ? !in_array($plan, $config['plans'], true) : $plan !== '';
    if ($first === '' || $last === '' || !is_email($email) || preg_match_all('/\d/', $mobile) < 10 || !preg_match('/^[A-Z]{2}$/', $state) || !in_array($interest, $config['interests'], true) || $plan_invalid || !$consent) {
        status_header(400);
        echo wp_json_encode(array('message' => 'Please complete every required contact and consent field.'));
        exit;
    }

    $webhook = defined('EV_CARE_LEAD_WEBHOOK_URL') ? EV_CARE_LEAD_WEBHOOK_URL : getenv('EV_CARE_LEAD_WEBHOOK_URL');
    if (!$webhook) {
        $webhook = defined('EV_CONTACT_WEBHOOK_URL') ? EV_CONTACT_WEBHOOK_URL : getenv('EV_CONTACT_WEBHOOK_URL');
    }
    if (!$webhook || strpos($webhook, 'https://') !== 0) {
        status_header(503);
        echo wp_json_encode(array('message' => 'Assessment requests are temporarily unavailable. Please try again shortly.'));
        exit;
    }

    $lead = array(
        'type' => 'care-lead',
        'program' => $config['label'],
        'firstName' => $first,
        'lastName' => $last,
        'email' => $email,
        'state' => $state,
        'consent' => true,
        'availability' => 'service-area',
        'source' => $config['source'],
        'submittedAt' => gmdate('c'),
    );
    $lead['mobile'] = $mobile;
    $lead['interest'] = $interest;
    if ($plan !== '') { $lead['plan'] = $plan; }

    $response = wp_remote_post($webhook, array(
        'timeout' => 12,
        'headers' => array('Content-Type' => 'application/json'),
        'body' => wp_json_encode($lead),
    ));
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) < 200 || wp_remote_retrieve_response_code($response) >= 300) {
        status_header(502);
        echo wp_json_encode(array('message' => 'Assessment requests are temporarily unavailable. Please try again shortly.'));
        exit;
    }

    status_header(200);
    echo wp_json_encode(array('message' => 'Your request is with our care team. We will email you a secure link to complete your clinical assessment.'));
    exit;
}
add_action('template_redirect', 'eves_sisters_care_lead_endpoint', -1800);

/* Preserve the nonclinical request flow used by the exported treatment cards. */
function eves_sisters_treatment_request_endpoint() {
    if (is_admin()) { return; }
    $path = (string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if ($path !== '/api/treatment-request') { return; }

    header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
    if (strtoupper((string) $_SERVER['REQUEST_METHOD']) !== 'POST') {
        status_header(405);
        header('Allow: POST');
        echo wp_json_encode(array('message' => 'Method not allowed.'));
        exit;
    }

    $body = json_decode((string) file_get_contents('php://input'), true);
    $category_key = isset($body['category']) ? sanitize_key($body['category']) : '';
    $plan_key = isset($body['plan']) ? sanitize_key($body['plan']) : '';
    $catalog = array(
        'weight-management' => array(
            'label' => 'Weight Management', 'source' => '/care/weight-management',
            'plans' => array(
                'semaglutide' => array('Compounded semaglutide', 'plan'),
                'tirzepatide' => array('Compounded tirzepatide', 'plan'),
                'semaglutide-maintenance' => array('Compounded semaglutide maintenance', 'plan'),
                'tirzepatide-maintenance' => array('Compounded tirzepatide maintenance', 'plan'),
                'signature-bundle' => array('Signature', 'bundle'),
                'elite-bundle' => array('Elite', 'bundle'),
            ),
        ),
        'hormones-menopause' => array(
            'label' => 'Menopause & Hormones', 'source' => '/care/hormones-menopause',
            'plans' => array(
                'oral-hrt' => array('Oral HRT', 'plan'),
                'patch-hrt' => array('Patch HRT', 'plan'),
                'cream-hrt' => array('Cream HRT', 'plan'),
                'vaginal-comfort' => array('Vaginal Comfort', 'plan'),
                'hormone-signature-bundle' => array('Hormone Signature', 'bundle'),
            ),
        ),
        'skin-beauty' => array('label' => 'Skin & Beauty', 'source' => '/care/skin-beauty', 'plans' => array('tretinoin' => array('Tretinoin', 'plan'))),
        'eves-secret' => array('label' => 'Eve’s Secret™', 'source' => '/eves-secret', 'plans' => array('sexual-wellness-consultation' => array('Sexual wellness consultation', 'plan'))),
    );
    $config = isset($catalog[$category_key]) ? $catalog[$category_key] : null;
    $option = $config && isset($config['plans'][$plan_key]) ? $config['plans'][$plan_key] : null;
    $billing = isset($body['billing']) && $body['billing'] === 'prepaid' ? 'three months prepaid' : (isset($body['billing']) && $body['billing'] === 'monthly' ? 'month to month' : '');
    $first = isset($body['firstName']) ? sanitize_text_field($body['firstName']) : '';
    $last = isset($body['lastName']) ? sanitize_text_field($body['lastName']) : '';
    $email = isset($body['email']) ? sanitize_email($body['email']) : '';
    $mobile = isset($body['mobile']) ? sanitize_text_field($body['mobile']) : '';
    $state = isset($body['state']) ? strtoupper(sanitize_text_field($body['state'])) : '';
    $consent = isset($body['consent']) && $body['consent'] === true;

    if (!$config || !$option || !$billing || $first === '' || $last === '' || !is_email($email) || preg_match_all('/\d/', $mobile) < 10 || !preg_match('/^[A-Z]{2}$/', $state) || !$consent) {
        status_header(400);
        echo wp_json_encode(array('message' => 'Please complete every required request and consent field.'));
        exit;
    }

    $webhook = defined('EV_TREATMENT_REQUEST_WEBHOOK_URL') ? EV_TREATMENT_REQUEST_WEBHOOK_URL : getenv('EV_TREATMENT_REQUEST_WEBHOOK_URL');
    if (!$webhook) { $webhook = defined('EV_CARE_LEAD_WEBHOOK_URL') ? EV_CARE_LEAD_WEBHOOK_URL : getenv('EV_CARE_LEAD_WEBHOOK_URL'); }
    if (!$webhook) { $webhook = defined('EV_CONTACT_WEBHOOK_URL') ? EV_CONTACT_WEBHOOK_URL : getenv('EV_CONTACT_WEBHOOK_URL'); }
    if (!$webhook || strpos($webhook, 'https://') !== 0) {
        status_header(503);
        echo wp_json_encode(array('message' => 'Treatment requests are temporarily unavailable. Please try again shortly.'));
        exit;
    }

    $response = wp_remote_post($webhook, array(
        'timeout' => 12,
        'headers' => array('Content-Type' => 'application/json'),
        'body' => wp_json_encode(array(
            'type' => 'treatment-request', 'category' => $config['label'],
            'requestedPlan' => $option[0], 'requestType' => $option[1],
            'billingPreference' => $billing, 'firstName' => $first, 'lastName' => $last,
            'email' => $email, 'mobile' => $mobile, 'state' => $state,
            'consent' => true, 'source' => $config['source'], 'submittedAt' => gmdate('c'),
        )),
    ));
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) < 200 || wp_remote_retrieve_response_code($response) >= 300) {
        status_header(502);
        echo wp_json_encode(array('message' => 'Treatment requests are temporarily unavailable. Please try again shortly.'));
        exit;
    }

    status_header(200);
    echo wp_json_encode(array('message' => 'We received your nonclinical treatment request. We will email your secure clinical-assessment link and the next steps for your selected plan.'));
    exit;
}
add_action('template_redirect', 'eves_sisters_treatment_request_endpoint', -1750);

/* Enforce the public launch scope even when legacy WordPress page records exist. */
function eves_sisters_launch_scope_routes() {
    if (is_admin()) { return; }
    $path = trim((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $redirects = array(
        'pillars/weight-loss' => '/care/weight-management/',
        'pillars/hormones-menopause' => '/care/hormones-menopause/',
        'pillars/skin-beauty' => '/care/skin-beauty/',
        'weight-management' => '/care/weight-management/',
        'menopause-hormones' => '/care/hormones-menopause/',
        'skin-beauty' => '/care/skin-beauty/',
        'pillars/energy-performance' => '/care/',
        'pillars/recovery-rejuvenation' => '/care/recovery-rejuvenation/',
        'pillars/longevity-healthspan' => '/care/longevity-healthspan/',
        'energy-performance' => '/care/',
        'recovery' => '/care/recovery-rejuvenation/',
        'longevity' => '/care/longevity-healthspan/',
    );
    if (isset($redirects[$path])) {
        wp_safe_redirect(home_url($redirects[$path]), 301);
        exit;
    }

    $not_found = array('journal', 'peptide-care', 'get-started', 'shop', 'cart', 'checkout', 'my-account', 'care/energy-performance');
    if (in_array($path, $not_found, true)) {
        status_header(404);
        nocache_headers();
        $file = get_template_directory() . '/static-pages/404.html';
        if (is_readable($file)) { echo file_get_contents($file); }
        exit;
    }
}
add_action('template_redirect', 'eves_sisters_launch_scope_routes', -1100);

/* Exact visual mirror of the approved Vercel/Next.js pages. The pre-rendered
 * documents and their compiled assets ship inside the theme, while native
 * WordPress and WooCommerce routes continue through the normal template stack. */
function eves_sisters_static_mirror() {
    if (is_admin()) { return; }

    $path = trim((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $pages = array(
        '' => 'index.html',
        'about' => 'about.html',
        'care' => 'care.html',
        'contact' => 'contact.html',
        'disclaimer' => 'disclaimer.html',
        'faq' => 'faq.html',
        'hipaa-policy' => 'hipaa-policy.html',
        'privacy-policy' => 'privacy-policy.html',
        'subscription-cancellation' => 'subscription-cancellation.html',
        'telehealth-consent' => 'telehealth-consent.html',
        'terms-of-service' => 'terms-of-service.html',
        'treatments' => 'treatments.html',
        'eves-secret' => 'eves-secret.html',
        'packages/mrs-collection' => 'mrs-collection.html',
        'packages/mrs-jones' => 'mrs-jones.html',
        'packages/mrs-golden' => 'mrs-golden.html',
        'packages/mrs-robinson' => 'mrs-robinson.html',
        'care/weight-management' => 'care-weight-management.html',
        'care/hormones-menopause' => 'care-hormones-menopause.html',
        'care/skin-beauty' => 'care-skin-beauty.html',
        'care/longevity-healthspan' => 'care-longevity-healthspan.html',
        'care/recovery-rejuvenation' => 'care-recovery-rejuvenation.html',
    );

    if (!isset($pages[$path])) { return; }
    $file = get_template_directory() . '/static-pages/' . $pages[$path];
    if (!is_readable($file)) { return; }

    $html = file_get_contents($file);
    /* Pressable's nginx handles extension-bearing root URLs before WordPress,
     * so route compiled CSS/JS through an extensionless, allow-listed gateway.
     * This replacement only touches document asset tags; application links and
     * React-rendered page content remain byte-for-byte identical. */
    $html = preg_replace(
        '#/_next/static/([A-Za-z0-9_./-]+)#',
        '/next-asset-v2130?file=static/$1',
        $html
    );
    $html = preg_replace('#/icon\.svg\?[A-Za-z0-9]+#', '/site-icon', $html);

    status_header(200);
    header('Content-Type: text/html; charset=' . get_bloginfo('charset'));
    echo $html;
    exit;
}
add_action('template_redirect', 'eves_sisters_static_mirror', -1000);

function eves_sisters_menu_fallback() {
    $links = array('Home' => home_url('/'), 'Care' => home_url('/care/'), 'Packages' => home_url('/care/weight-management/#plans'), 'The Mrs. Collection' => home_url('/packages/mrs-collection/'), 'Eve’s Secret™' => home_url('/eves-secret/'), 'Our Approach' => home_url('/about/#philosophy'), 'About' => home_url('/about/'), 'Contact' => home_url('/contact/'));
    foreach ($links as $label => $url) { printf('<a href="%s">%s</a>', esc_url($url), esc_html($label)); }
}
